import { Header } from "@/components/header";
import { Hero } from "@/components/hero";
import { MapCard } from "@/components/map-card";
import { Footer } from "@/components/footer";

const maps = [
  {
    title: "Overworld",
    description: "Die Overworld des FlexiSMP's. Da hier die Datei sehr groß ist können bei Anfrage auch bestimmte Chunks gesendet werden. Falls da interesse besteht einfach via. Discord bei 'erhaltunq.' melden.",
    dimension: "overworld" as const,
    size: "~2.5 GB",
    lastUpdated: "Januar 2026",
    downloadUrl: "#",
    discordUrl: "https://discord.gg/Mh8Cs5H6hZ",
    unavailable: true,
  },
  {
    title: "Nether",
    description: "Die Nether-Dimension mit allen Portalen, Gold-Farmen und Netherhubs.",
    dimension: "nether" as const,
    size: "410 MB",
    lastUpdated: "Januar 2026",
    downloadUrl: "https://www.swisstransfer.com/d/ec14fd70-7f21-436f-822f-979b522be419",
  },
  {
    title: "The End",
    description: "Die End-Dimension mit dem Enderkampf-Arena und allen End-City Erkundungen.",
    dimension: "end" as const,
    size: "74.1 MB",
    lastUpdated: "Januar 2026",
    downloadUrl: "https://www.swisstransfer.com/d/321b59a0-d4f1-4a7a-8e3f-f8514dc3cd60",
  },
];

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <Hero />
        <section className="py-12 md:py-16">
          <div className="mx-auto max-w-6xl px-4">
            <h2 className="mb-8 text-center text-2xl font-bold md:text-3xl">
              Verfügbare Maps
            </h2>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {maps.map((map) => (
                <MapCard key={map.dimension} {...map} />
              ))}
            </div>
          </div>
        </section>
        
        <section className="border-t border-border/50 py-12 md:py-16">
          <div className="mx-auto max-w-3xl px-4 text-center">
            <h3 className="mb-4 text-xl font-semibold">So verwendest du die Maps</h3>
            <div className="space-y-3 text-left text-muted-foreground">
              <p className="flex gap-3">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/20 text-xs font-bold text-primary">1</span>
                <span>Lade die gewünschte Map herunter und entpacke die ZIP-Datei.</span>
              </p>
              <p className="flex gap-3">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/20 text-xs font-bold text-primary">2</span>
                <span>Kopiere den Ordner in deinen Minecraft Saves-Ordner (<code className="rounded bg-secondary px-1.5 py-0.5 text-xs">.minecraft/saves</code>).</span>
              </p>
              <p className="flex gap-3">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/20 text-xs font-bold text-primary">3</span>
                <span>Starte Minecraft und wähle die Welt im Singleplayer-Menü aus.</span>
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
