export function Footer() {
  return (
    <footer className="border-t border-border/50 bg-card/30 py-8 mt-auto">
      <div className="mx-auto max-w-6xl px-4 text-center">
        <p className="text-sm text-muted-foreground">
          © {new Date().getFullYear()} FlexiSMP • Gehostet auf{" "}
          <a
            href="https://erhaltunq.de"
            target="_blank"
            rel="noopener noreferrer"
            className="text-primary hover:underline"
          >
            erhaltunq.de
          </a>
        </p>
        <p className="mt-2 text-xs text-muted-foreground/70">
          Minecraft ist eine Marke von Mojang Studios.
        </p>
      </div>
    </footer>
  );
}
