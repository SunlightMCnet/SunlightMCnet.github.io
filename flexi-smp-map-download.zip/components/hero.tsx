import { Map, Download, Server } from "lucide-react";

export function Hero() {
  return (
    <section className="relative overflow-hidden py-16 md:py-24">
      {/* Background decoration */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute left-1/4 top-1/4 h-64 w-64 rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute right-1/4 bottom-1/4 h-64 w-64 rounded-full bg-accent/5 blur-3xl" />
      </div>
      
      <div className="mx-auto max-w-6xl px-4 text-center">
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-secondary/50 px-4 py-2 text-sm">
          <Server className="h-4 w-4 text-primary" />
          <span className="text-muted-foreground">FlexiSMP Server Maps</span>
        </div>
        
        <h1 className="mb-4 text-4xl font-bold tracking-tight md:text-5xl lg:text-6xl text-balance">
          Map Downloads
        </h1>
        
        <p className="mx-auto mb-8 max-w-2xl text-lg text-muted-foreground text-pretty">
          Lade die kompletten Welten des FlexiSMP Servers herunter. 
          Alle Dimensionen verfügbar: Overworld, Nether und End.
        </p>
        
        <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <Map className="h-5 w-5 text-primary" />
            <span>3 Dimensionen</span>
          </div>
          <div className="flex items-center gap-2">
            <Download className="h-5 w-5 text-primary" />
            <span>Direkter Download</span>
          </div>
        </div>
      </div>
    </section>
  );
}
