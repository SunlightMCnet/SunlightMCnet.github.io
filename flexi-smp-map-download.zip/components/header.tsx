import { Globe } from "lucide-react";

export function Header() {
  return (
    <header className="border-b border-border/50 bg-card/50 backdrop-blur-md sticky top-0 z-50">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            <Globe className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="font-bold text-lg leading-none">FlexiSMP</h1>
            <p className="text-xs text-muted-foreground">erhaltunq.de</p>
          </div>
        </div>
        <nav>
          <a
            href="https://erhaltunq.de"
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            Hauptseite
          </a>
        </nav>
      </div>
    </header>
  );
}
